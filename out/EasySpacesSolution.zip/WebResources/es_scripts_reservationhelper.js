// Reservation Helper Functions
(function() {
    'use strict';
    
    window.ReservationHelper = {
        formatDate: function(date) {
            if (!date) return '';
            return date.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
        },
        
        getDuration: function(startDate, endDate) {
            if (!startDate || !endDate) return 0;
            return Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
        },
        
        validateCapacity: function(guestCount, maxCapacity) {
            return guestCount <= maxCapacity;
        },
        
        getStatusColor: function(status) {
            switch(status) {
                case 10013: return '#FFA500'; // Draft - Orange
                case 10014: return '#1E90FF'; // Submitted - Blue
                case 10015: return '#32CD32'; // Confirmed - Green
                case 10016: return '#DC143C'; // Cancelled - Red
                case 10017: return '#808080'; // Completed - Gray
                default: return '#000000';
            }
        }
    };
})();
