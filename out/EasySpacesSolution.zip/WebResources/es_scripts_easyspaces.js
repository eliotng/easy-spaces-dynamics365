// Easy Spaces JavaScript Library
// Source: /web-resources/es_openRecordAction.js
(function(window, Xrm) {
    'use strict';
    
    window.EasySpaces = window.EasySpaces || {};
    
    EasySpaces.openRecord = function(primaryControl) {
        var formContext = primaryControl;
        var recordId = formContext.data.entity.getId();
        var entityName = formContext.data.entity.getEntityName();
        
        Xrm.Navigation.navigateTo({
            pageType: "entityrecord",
            entityName: entityName,
            entityId: recordId.replace('{', '').replace('}', ''),
            formType: 2
        });
    };
    
    EasySpaces.validateDates = function(executionContext) {
        var formContext = executionContext.getFormContext();
        var startDate = formContext.getAttribute("es_startdate");
        var endDate = formContext.getAttribute("es_enddate");
        
        if (!startDate || !endDate) return true;
        
        var start = startDate.getValue();
        var end = endDate.getValue();
        
        if (start && end && start >= end) {
            formContext.ui.setFormNotification(
                "End date must be after start date",
                "ERROR",
                "date_validation"
            );
            return false;
        }
        formContext.ui.clearFormNotification("date_validation");
        return true;
    };
    
    EasySpaces.calculatePricing = function(executionContext) {
        var formContext = executionContext.getFormContext();
        var spaceId = formContext.getAttribute("es_spaceid");
        var startDate = formContext.getAttribute("es_startdate");
        var endDate = formContext.getAttribute("es_enddate");
        
        if (!spaceId || !spaceId.getValue() || !startDate || !endDate) return;
        
        var space = spaceId.getValue()[0];
        var start = startDate.getValue();
        var end = endDate.getValue();
        
        if (!start || !end) return;
        
        Xrm.WebApi.retrieveRecord("es_space", space.id, "?$select=es_dailyrate,es_weeklyrate,es_monthlyrate")
            .then(function(result) {
                var days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
                var price = 0;
                
                var dailyRate = result.es_dailyrate || 0;
                var weeklyRate = result.es_weeklyrate || 0;
                var monthlyRate = result.es_monthlyrate || 0;
                
                if (days >= 30 && monthlyRate > 0) {
                    price = Math.floor(days / 30) * monthlyRate + (days % 30) * dailyRate;
                } else if (days >= 7 && weeklyRate > 0) {
                    price = Math.floor(days / 7) * weeklyRate + (days % 7) * dailyRate;
                } else {
                    price = days * dailyRate;
                }
                
                var totalPrice = formContext.getAttribute("es_totalprice");
                if (totalPrice) {
                    totalPrice.setValue(price);
                }
            });
    };
    
    EasySpaces.checkConflicts = function(executionContext) {
        var formContext = executionContext.getFormContext();
        var spaceId = formContext.getAttribute("es_spaceid");
        var startDate = formContext.getAttribute("es_startdate");
        var endDate = formContext.getAttribute("es_enddate");
        
        if (!spaceId || !spaceId.getValue() || !startDate || !endDate) return;
        
        var space = spaceId.getValue()[0];
        var start = startDate.getValue();
        var end = endDate.getValue();
        
        if (!start || !end) return;
        
        var filter = "es_spaceid eq " + space.id + 
                    " and es_startdate lt " + end.toISOString() +
                    " and es_enddate gt " + start.toISOString() +
                    " and es_status ne 10016";
        
        Xrm.WebApi.retrieveMultipleRecords("es_reservation", "?$filter=" + encodeURIComponent(filter))
            .then(function(result) {
                if (result.entities && result.entities.length > 0) {
                    formContext.ui.setFormNotification(
                        "This space has conflicting reservations",
                        "WARNING",
                        "conflict_check"
                    );
                } else {
                    formContext.ui.clearFormNotification("conflict_check");
                }
            });
    };
})(window, window.Xrm);
