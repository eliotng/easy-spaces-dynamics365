using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace EasySpaces.Plugins
{
    /// <summary>
    /// Plugin for Reservation entity business logic
    /// </summary>
    public class ReservationPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Get execution context
            IPluginExecutionContext context = 
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            
            // Get organization service
            IOrganizationServiceFactory serviceFactory = 
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            
            // Get tracing service
            ITracingService tracingService = 
                (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            
            try
            {
                // Check if this is a Create or Update message
                if (context.MessageName == "Create" || context.MessageName == "Update")
                {
                    Entity entity = (Entity)context.InputParameters["Target"];
                    
                    if (entity.LogicalName == "es_reservation")
                    {
                        // Validate reservation dates
                        ValidateReservationDates(entity, service, tracingService);
                        
                        // Check space availability
                        CheckSpaceAvailability(entity, service, tracingService);
                        
                        // Calculate total amount
                        CalculateTotalAmount(entity, service, tracingService);
                        
                        // Update space status
                        UpdateSpaceStatus(entity, service, tracingService);
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("ReservationPlugin Error: {0}", ex.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
        
        private void ValidateReservationDates(Entity reservation, IOrganizationService service, ITracingService trace)
        {
            if (reservation.Contains("es_startdate") && reservation.Contains("es_enddate"))
            {
                DateTime startDate = (DateTime)reservation["es_startdate"];
                DateTime endDate = (DateTime)reservation["es_enddate"];
                
                if (startDate >= endDate)
                {
                    throw new InvalidPluginExecutionException("End date must be after start date.");
                }
                
                if (startDate < DateTime.Today)
                {
                    throw new InvalidPluginExecutionException("Cannot create reservations in the past.");
                }
                
                // Calculate total days
                int totalDays = (endDate - startDate).Days;
                reservation["es_totaldays"] = totalDays;
                
                trace.Trace("Reservation dates validated. Total days: {0}", totalDays);
            }
        }
        
        private void CheckSpaceAvailability(Entity reservation, IOrganizationService service, ITracingService trace)
        {
            if (reservation.Contains("es_spaceid") && reservation.Contains("es_startdate") && reservation.Contains("es_enddate"))
            {
                EntityReference spaceRef = (EntityReference)reservation["es_spaceid"];
                DateTime startDate = (DateTime)reservation["es_startdate"];
                DateTime endDate = (DateTime)reservation["es_enddate"];
                
                // Check for conflicting reservations
                QueryExpression query = new QueryExpression("es_reservation");
                query.ColumnSet = new ColumnSet("es_reservationid");
                query.Criteria.AddCondition("es_spaceid", ConditionOperator.Equal, spaceRef.Id);
                query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0); // Active
                
                // Check for date overlap
                FilterExpression dateFilter = new FilterExpression(LogicalOperator.Or);
                dateFilter.AddCondition("es_startdate", ConditionOperator.Between, new object[] { startDate, endDate });
                dateFilter.AddCondition("es_enddate", ConditionOperator.Between, new object[] { startDate, endDate });
                
                query.Criteria.AddFilter(dateFilter);
                
                // Exclude current reservation if updating
                if (reservation.Id != Guid.Empty)
                {
                    query.Criteria.AddCondition("es_reservationid", ConditionOperator.NotEqual, reservation.Id);
                }
                
                EntityCollection conflicts = service.RetrieveMultiple(query);
                
                if (conflicts.Entities.Count > 0)
                {
                    throw new InvalidPluginExecutionException("This space is already reserved for the selected dates.");
                }
                
                trace.Trace("Space availability confirmed.");
            }
        }
        
        private void CalculateTotalAmount(Entity reservation, IOrganizationService service, ITracingService trace)
        {
            if (reservation.Contains("es_spaceid") && reservation.Contains("es_totaldays"))
            {
                EntityReference spaceRef = (EntityReference)reservation["es_spaceid"];
                int totalDays = (int)reservation["es_totaldays"];
                
                // Retrieve space pricing
                Entity space = service.Retrieve("es_space", spaceRef.Id, 
                    new ColumnSet("es_dailyrate", "es_weeklyrate", "es_monthlyrate"));
                
                decimal totalAmount = 0;
                
                if (space.Contains("es_monthlyrate") && totalDays >= 30)
                {
                    decimal monthlyRate = space.GetAttributeValue<Money>("es_monthlyrate").Value;
                    int months = totalDays / 30;
                    int remainingDays = totalDays % 30;
                    
                    totalAmount = (months * monthlyRate);
                    
                    if (remainingDays > 0 && space.Contains("es_dailyrate"))
                    {
                        decimal dailyRate = space.GetAttributeValue<Money>("es_dailyrate").Value;
                        totalAmount += (remainingDays * dailyRate);
                    }
                }
                else if (space.Contains("es_weeklyrate") && totalDays >= 7)
                {
                    decimal weeklyRate = space.GetAttributeValue<Money>("es_weeklyrate").Value;
                    int weeks = totalDays / 7;
                    int remainingDays = totalDays % 7;
                    
                    totalAmount = (weeks * weeklyRate);
                    
                    if (remainingDays > 0 && space.Contains("es_dailyrate"))
                    {
                        decimal dailyRate = space.GetAttributeValue<Money>("es_dailyrate").Value;
                        totalAmount += (remainingDays * dailyRate);
                    }
                }
                else if (space.Contains("es_dailyrate"))
                {
                    decimal dailyRate = space.GetAttributeValue<Money>("es_dailyrate").Value;
                    totalAmount = totalDays * dailyRate;
                }
                
                reservation["es_totalamount"] = new Money(totalAmount);
                trace.Trace("Total amount calculated: {0}", totalAmount);
            }
        }
        
        private void UpdateSpaceStatus(Entity reservation, IOrganizationService service, ITracingService trace)
        {
            if (reservation.Contains("es_spaceid"))
            {
                EntityReference spaceRef = (EntityReference)reservation["es_spaceid"];
                
                // Update space status to Occupied
                Entity spaceUpdate = new Entity("es_space", spaceRef.Id);
                spaceUpdate["es_status"] = new OptionSetValue(100000001); // Occupied
                
                service.Update(spaceUpdate);
                trace.Trace("Space status updated to Occupied.");
            }
        }
    }
}
