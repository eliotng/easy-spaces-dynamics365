// Easy Spaces Application Main JavaScript
var EasySpaces = window.EasySpaces || {};

(function() {
    'use strict';
    
    EasySpaces.App = {
        // Initialize application
        init: function() {
            console.log('Easy Spaces Application Initialized');
            this.setupEventHandlers();
            this.loadDashboard();
        },
        
        // Setup event handlers
        setupEventHandlers: function() {
            if (typeof Xrm !== 'undefined') {
                // Form events
                if (Xrm.Page) {
                    this.setupFormEvents();
                }
            }
        },
        
        // Setup form-specific events
        setupFormEvents: function() {
            var formContext = Xrm.Page;
            
            // Market form events
            if (formContext.data.entity.getEntityName() === 'es_market') {
                formContext.getAttribute('es_city').addOnChange(this.onCityChange);
            }
            
            // Space form events
            if (formContext.data.entity.getEntityName() === 'es_space') {
                formContext.getAttribute('es_dailyrate').addOnChange(this.calculatePricing);
                formContext.getAttribute('es_weeklyrate').addOnChange(this.calculatePricing);
            }
            
            // Reservation form events
            if (formContext.data.entity.getEntityName() === 'es_reservation') {
                formContext.getAttribute('es_startdate').addOnChange(this.validateDates);
                formContext.getAttribute('es_enddate').addOnChange(this.validateDates);
            }
        },
        
        // City change handler
        onCityChange: function() {
            var city = Xrm.Page.getAttribute('es_city').getValue();
            if (city) {
                // Auto-populate state based on city
                var stateMap = {
                    'San Francisco': 'CA',
                    'New York': 'NY',
                    'Chicago': 'IL',
                    'Seattle': 'WA',
                    'Austin': 'TX'
                };
                
                if (stateMap[city]) {
                    Xrm.Page.getAttribute('es_state').setValue(stateMap[city]);
                }
            }
        },
        
        // Calculate pricing for spaces
        calculatePricing: function() {
            var dailyRate = Xrm.Page.getAttribute('es_dailyrate').getValue();
            var weeklyRate = Xrm.Page.getAttribute('es_weeklyrate').getValue();
            
            if (dailyRate && !weeklyRate) {
                // Auto-calculate weekly rate with 10% discount
                Xrm.Page.getAttribute('es_weeklyrate').setValue(dailyRate * 7 * 0.9);
            }
            
            if (!dailyRate && weeklyRate) {
                // Calculate daily rate from weekly
                Xrm.Page.getAttribute('es_dailyrate').setValue(weeklyRate / 7 / 0.9);
            }
        },
        
        // Validate reservation dates
        validateDates: function() {
            var startDate = Xrm.Page.getAttribute('es_startdate').getValue();
            var endDate = Xrm.Page.getAttribute('es_enddate').getValue();
            
            if (startDate && endDate) {
                if (startDate >= endDate) {
                    Xrm.Page.ui.setFormNotification(
                        'End date must be after start date',
                        'ERROR',
                        'date_validation'
                    );
                    return false;
                } else {
                    Xrm.Page.ui.clearFormNotification('date_validation');
                }
                
                // Calculate total days and amount
                var days = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
                Xrm.Page.getAttribute('es_totaldays').setValue(days);
                
                // Calculate total amount based on space pricing
                this.calculateTotalAmount(days);
            }
            return true;
        },
        
        // Calculate total reservation amount
        calculateTotalAmount: function(days) {
            var spaceId = Xrm.Page.getAttribute('es_spaceid').getValue();
            if (spaceId && spaceId.length > 0) {
                // Retrieve space pricing
                Xrm.WebApi.retrieveRecord('es_space', spaceId[0].id, '?$select=es_dailyrate,es_weeklyrate')
                    .then(function(space) {
                        var totalAmount = 0;
                        
                        if (days >= 7 && space.es_weeklyrate) {
                            // Use weekly rate for 7+ days
                            var weeks = Math.floor(days / 7);
                            var remainingDays = days % 7;
                            totalAmount = (weeks * space.es_weeklyrate) + (remainingDays * space.es_dailyrate);
                        } else if (space.es_dailyrate) {
                            // Use daily rate
                            totalAmount = days * space.es_dailyrate;
                        }
                        
                        Xrm.Page.getAttribute('es_totalamount').setValue(totalAmount);
                    })
                    .catch(function(error) {
                        console.error('Error retrieving space pricing:', error);
                    });
            }
        },
        
        // Load dashboard data
        loadDashboard: function() {
            if (typeof Xrm !== 'undefined' && Xrm.WebApi) {
                this.loadDashboardMetrics();
            }
        },
        
        // Load dashboard metrics
        loadDashboardMetrics: function() {
            var promises = [
                Xrm.WebApi.retrieveMultipleRecords('es_market', '?$select=es_marketid&$count=true'),
                Xrm.WebApi.retrieveMultipleRecords('es_space', '?$select=es_spaceid&$count=true'),
                Xrm.WebApi.retrieveMultipleRecords('es_reservation', '?$select=es_reservationid&$count=true')
            ];
            
            Promise.all(promises).then(function(results) {
                console.log('Dashboard Metrics:');
                console.log('Total Markets:', results[0].entities.length);
                console.log('Total Spaces:', results[1].entities.length);
                console.log('Total Reservations:', results[2].entities.length);
            });
        }
    };
    
    // Auto-initialize on page load
    if (typeof Xrm !== 'undefined') {
        EasySpaces.App.init();
    }
})();
